/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prutprommart
 */
public class AccountRecord {

    private int accountNumber;
    private String name;
    private double balance;
    private int transCnt = 0;

    public AccountRecord(int ac, String name, double balance) {
        this.accountNumber = ac;
        this.name = name;
        this.balance = balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    public int getTransCnt() {
        return transCnt;
    }

    public void combine(TransactionRecord t) {
        if (t.getAccountNumber() == accountNumber) {
            balance += t.getAmount();
            transCnt++;
        }
    }
}
